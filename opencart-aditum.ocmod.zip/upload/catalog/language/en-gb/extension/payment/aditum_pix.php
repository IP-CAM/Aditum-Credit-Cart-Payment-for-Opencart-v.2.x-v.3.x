<?php
// Text
$_['text_title'] = 'Aditum - Pix';
<?php
// Text
$_['text_title'] = 'Aditum - Cartão de Crédito';
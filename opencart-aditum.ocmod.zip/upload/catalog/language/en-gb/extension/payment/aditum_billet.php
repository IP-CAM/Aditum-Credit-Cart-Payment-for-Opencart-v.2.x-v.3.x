<?php
// Text
$_['text_title'] = 'Aditum - Boleto';